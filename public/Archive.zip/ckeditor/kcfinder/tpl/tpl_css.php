<link href="css.php?type=<?php echo $this->type ?>" rel="stylesheet" type="text/css" />
<link href="themes/<?php echo $this->config['theme'] ?>/style.css" rel="stylesheet" type="text/css" />
